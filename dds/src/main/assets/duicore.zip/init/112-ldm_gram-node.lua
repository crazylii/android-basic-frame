--
-- Created by IntelliJ IDEA.
-- User: jiahuanchen
-- Date: 19-8-8
-- Time: 上午10:33
-- To change this template use File | Settings | File Templates.
--

require('luabin')
luabin.path = playerconf.DUICORE_HOME .. '/hybrid.lub;' .. playerconf.DATA_HOME .. '/core.lub;' .. playerconf.DUICORE_HOME .. '/corelib.lub'

local ldm_gram = require 'player.node.dms.ldm.gram'
ldm_gram:run()

