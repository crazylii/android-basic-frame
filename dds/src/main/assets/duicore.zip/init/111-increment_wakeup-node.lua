require('luabin')
luabin.path = playerconf.DUICORE_HOME .. '/hybrid.lub;' .. playerconf.DATA_HOME .. '/core.lub;' .. playerconf.DUICORE_HOME .. '/corelib.lub'

local increment_wakeup_node = require 'player.node.increment_wakeup'
increment_wakeup_node:run()

