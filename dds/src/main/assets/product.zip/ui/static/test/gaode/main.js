(function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeof module === 'object')
		module.exports = factory();
	else if(typeof define === 'function' && define.amd)
		define("DuiCustom", [], factory);
	else if(typeof exports === 'object')
		exports["DuiCustom"] = factory();
	else
		root["DuiCustom"] = factory();
})(this, function() {
return /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/lib/";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 9);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

/* globals __VUE_SSR_CONTEXT__ */

// this module is a runtime utility for cleaner component module output and will
// be included in the final webpack user bundle

module.exports = function normalizeComponent (
  rawScriptExports,
  compiledTemplate,
  injectStyles,
  scopeId,
  moduleIdentifier /* server only */
) {
  var esModule
  var scriptExports = rawScriptExports = rawScriptExports || {}

  // ES6 modules interop
  var type = typeof rawScriptExports.default
  if (type === 'object' || type === 'function') {
    esModule = rawScriptExports
    scriptExports = rawScriptExports.default
  }

  // Vue.extend constructor export interop
  var options = typeof scriptExports === 'function'
    ? scriptExports.options
    : scriptExports

  // render functions
  if (compiledTemplate) {
    options.render = compiledTemplate.render
    options.staticRenderFns = compiledTemplate.staticRenderFns
  }

  // scopedId
  if (scopeId) {
    options._scopeId = scopeId
  }

  var hook
  if (moduleIdentifier) { // server build
    hook = function (context) {
      // 2.3 injection
      context =
        context || // cached call
        (this.$vnode && this.$vnode.ssrContext) || // stateful
        (this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext) // functional
      // 2.2 with runInNewContext: true
      if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
        context = __VUE_SSR_CONTEXT__
      }
      // inject component styles
      if (injectStyles) {
        injectStyles.call(this, context)
      }
      // register component module identifier for async chunk inferrence
      if (context && context._registeredComponents) {
        context._registeredComponents.add(moduleIdentifier)
      }
    }
    // used by ssr in case component is cached and beforeCreate
    // never gets called
    options._ssrRegister = hook
  } else if (injectStyles) {
    hook = injectStyles
  }

  if (hook) {
    var functional = options.functional
    var existing = functional
      ? options.render
      : options.beforeCreate
    if (!functional) {
      // inject component registration as beforeCreate hook
      options.beforeCreate = existing
        ? [].concat(existing, hook)
        : [hook]
    } else {
      // register for functioal component in vue file
      options.render = function renderWithStyleInjection (h, context) {
        hook.call(context)
        return existing(h, context)
      }
    }
  }

  return {
    esModule: esModule,
    exports: scriptExports,
    options: options
  }
}


/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(12)
}
var Component = __webpack_require__(0)(
  /* script */
  __webpack_require__(5),
  /* template */
  __webpack_require__(16),
  /* styles */
  injectStyle,
  /* scopeId */
  "data-v-471cf1f5",
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(11)
}
var Component = __webpack_require__(0)(
  /* script */
  __webpack_require__(6),
  /* template */
  __webpack_require__(15),
  /* styles */
  injectStyle,
  /* scopeId */
  "data-v-3a3b211b",
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(14)
}
var Component = __webpack_require__(0)(
  /* script */
  __webpack_require__(7),
  /* template */
  __webpack_require__(18),
  /* styles */
  injectStyle,
  /* scopeId */
  "data-v-d2518bc6",
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(13)
}
var Component = __webpack_require__(0)(
  /* script */
  __webpack_require__(8),
  /* template */
  __webpack_require__(17),
  /* styles */
  injectStyle,
  /* scopeId */
  "data-v-486dd760",
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 5 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
//
//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'customContentCard',
  widgetType: 'content',
  testData: {
    data: {
      title: '刘德华(卡片标题)',
      subTitle: '刘德华，BBS，MH，JP，香港知名演员、歌手及电影制作人，1990年代获封香港乐坛“四大天王”之一，也是吉尼斯世界纪录大全中获奖最多的香港歌手；电影方面他获得三次香港电影金像奖最佳男主角和两次金马奖最佳男主角，至今参演超过140部电影。(卡片内容)'
    }
  },

  props: {
    message: Object
  }
});

/***/ }),
/* 6 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__assets_fonts_iconfont_css__ = __webpack_require__(10);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__assets_fonts_iconfont_css___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__assets_fonts_iconfont_css__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
  widgetName: 'gaodeList',
  widgetType: 'list',
  fullscreen: true,

  mounted: function mounted() {
    var _this = this;

    // 同步距离条件
    if (this.message.data.radius) {
      this.currentDistance = {
        value: this.message.data.radius + '\u7C73',
        text: this.message.data.radius + '\u7C73'
      };
    }
    // 同步美食类型条件
    if (this.message.data.keyword) {
      var keyword = this.message.data.keyword;
      this.typeList.forEach(function (type) {
        if (type.text === keyword) {
          _this.currentType = type;
        } else if (type.subTypes) {
          type.subTypes.forEach(function (subType) {
            if (subType.text === keyword) {
              _this.currentType = type;
              _this.currentSubType = subType;
            }
          });
        }
      });
    }
    // 同步排序类型条件
    if (this.message.data.sortkey) {
      if (this.message.data.sortkey === '智能') {
        this.currentOrderType = {
          value: '\u667A\u80FD\u6392\u5E8F',
          text: '\u667A\u80FD\u6392\u5E8F'
        };
      } else {
        this.currentOrderType = {
          value: '\u6309' + this.message.data.sortkey + '\u6392\u5E8F',
          text: '\u6309' + this.message.data.sortkey + '\u6392\u5E8F'
        };
      }
    }
  },
  data: function data() {
    return {
      currentMenu: '',
      currentDistance: {
        value: '1000米',
        text: '1000米'
      },
      currentType: {
        value: '全部',
        text: '全部分类'
      },
      currentSubType: {},
      currentOrderType: {
        value: '智能排序',
        text: '智能排序'
      },
      distanceList: [{
        value: '1000米',
        text: '1000米'
      }, {
        value: '2000米',
        text: '2000米'
      }, {
        value: '5000米',
        text: '5000米'
      }, {
        value: '全城',
        text: '全城'
      }],
      orderTypeList: [{
        value: '智能排序',
        text: '智能排序'
      }, {
        value: '按距离排序',
        text: '按距离排序'
      }, {
        value: '按价格排序',
        text: '按价格排序'
      }, {
        value: '按评分排序',
        text: '按评分排序'
      }],
      typeList: [{
        text: '全部分类',
        value: '我想吃美食'
      }, {
        text: '中餐厅',
        value: '我想去中餐厅吃美食',
        subTypes: [{
          value: '我想去中餐厅吃美食',
          text: '全部'
        }, {
          value: '我想吃火锅',
          text: '火锅'
        }, {
          value: '我想吃自助餐',
          text: '自助餐'
        }, {
          value: '我想吃川菜',
          text: '川菜'
        }, {
          value: '我想吃湘菜',
          text: '湘菜'
        }, {
          value: '我想吃粤菜',
          text: '粤菜'
        }, {
          value: '我想吃上海菜',
          text: '上海菜'
        }, {
          value: '我想吃鲁菜',
          text: '鲁菜'
        }, {
          value: '我想吃东北菜',
          text: '东北菜'
        }, {
          value: '我想吃江浙菜',
          text: '江浙菜'
        }, {
          value: '我想吃北京菜',
          text: '北京菜'
        }, {
          value: '我想吃云贵菜',
          text: '云贵菜'
        }, {
          value: '我想吃台湾菜',
          text: '台湾菜'
        }, {
          value: '我想吃湖北菜',
          text: '湖北菜'
        }, {
          value: '我想吃西北菜',
          text: '西北菜'
        }, {
          value: '我想吃安徽菜',
          text: '安徽菜'
        }, {
          value: '我想吃福建菜',
          text: '福建菜'
        }, {
          value: '我想吃潮州菜',
          text: '潮州菜'
        }, {
          value: '我想吃海鲜',
          text: '海鲜'
        }, {
          value: '我想去素菜馆吃美食',
          text: '素菜馆'
        }, {
          value: '我想去清真菜馆吃美食',
          text: '清真菜馆'
        }, {
          value: '我想去老字号吃美食',
          text: '老字号'
        }]
      }, {
        text: '西餐厅',
        value: '我想去西餐厅吃美食',
        subTypes: [{
          value: '我想去西餐厅吃美食',
          text: '全部'
        }, {
          value: '我想吃牛排',
          text: '牛排'
        }, {
          value: '我想吃意大利菜',
          text: '意大利菜'
        }, {
          value: '我想吃法国菜',
          text: '法国菜'
        }, {
          value: '我想吃地中海菜',
          text: '地中海菜'
        }, {
          value: '我想吃美式风味',
          text: '美式风味'
        }, {
          value: '我想吃英国风味',
          text: '英国风味'
        }, {
          value: '我想吃俄国菜',
          text: '俄国菜'
        }, {
          value: '我想吃葡萄牙菜',
          text: '葡萄牙菜'
        }, {
          value: '我想吃德国菜',
          text: '德国菜'
        }, {
          value: '我想吃巴西烤肉',
          text: '巴西烤肉'
        }, {
          value: '我想吃墨西哥菜',
          text: '墨西哥菜'
        }]
      }, {
        text: '日本料理',
        value: '我想吃日本料理'
      }, {
        text: '韩国料理',
        value: '我想吃韩国料理'
      }, {
        text: '东南亚餐厅',
        value: '我想去东南亚餐厅吃美食',
        subTypes: [{
          value: '我想去东南亚餐厅吃美食',
          text: '全部'
        }, {
          value: '我想吃泰国菜',
          text: '泰国菜'
        }, {
          value: '我想吃越南菜',
          text: '越南菜'
        }, {
          value: '我想吃印度菜',
          text: '印度菜'
        }]
      }, {
        text: '快餐',
        value: '我想吃快餐',
        subTypes: [{
          value: '我想吃快餐',
          text: '全部'
        }, {
          value: '我想吃肯德基',
          text: '肯德基'
        }, {
          value: '我想吃麦当劳',
          text: '麦当劳'
        }, {
          value: '我想吃必胜客',
          text: '必胜客'
        }, {
          value: '我想吃茶餐厅',
          text: '茶餐厅'
        }, {
          value: '我想吃吉野家',
          text: '吉野家'
        }, {
          value: '我想吃大快活',
          text: '大快活'
        }]
      }, {
        text: '咖啡厅',
        value: '我想去咖啡厅吃美食'
      }, {
        text: '茶艺馆',
        value: '我想去茶艺馆吃美食'
      }, {
        text: '冷饮店',
        value: '我想去冷饮店吃美食'
      }, {
        text: '糕饼店',
        value: '我想去糕饼店吃美食'
      }, {
        text: '甜品店',
        value: '我想去甜品店吃美食'
      }]
    };
  },


  props: {
    message: Object
  },

  methods: {
    handleClick: function handleClick(index) {
      if (!window.Dui) return;
      window.Dui.send({
        'event': 'list.item.select',
        'data': {
          'index': index + 1
        }
      });
    },
    clickMenu: function clickMenu(key) {
      this.currentMenu = this.currentMenu === key ? '' : key;
    },
    selectDistance: function selectDistance(distance) {
      this.currentMenu = '';
      this.currentDistance = distance;

      if (!window.Dui) return;
      window.Dui.send({
        'event': 'recommendation.item.select',
        'data': {
          'text': distance.value
        }
      });
    },
    selectType: function selectType(type) {
      this.currentSubType = {};
      this.currentType = type;
      if (!type.subTypes || !type.subTypes[0]) {
        this.currentMenu = '';
        if (!window.Dui) return;
        window.Dui.send({
          'event': 'recommendation.item.select',
          'data': {
            'text': type.value
          }
        });
      }
    },
    selectSubType: function selectSubType(type, subType) {
      this.currentMenu = '';
      this.currentType = type;
      this.currentSubType = subType;

      if (!window.Dui) return;
      window.Dui.send({
        'event': 'recommendation.item.select',
        'data': {
          'text': subType.value
        }
      });
    },
    selectOrderType: function selectOrderType(orderType) {
      this.currentMenu = '';
      this.currentOrderType = orderType;

      if (!window.Dui) return;
      window.Dui.send({
        'event': 'recommendation.item.select',
        'data': {
          'text': orderType.value
        }
      });
    },
    getRate: function getRate(item) {
      if (item.extra && item.extra.biz_ext && item.extra.biz_ext.rating && (typeof item.extra.biz_ext.rating === 'string' || typeof item.extra.biz_ext.rating === 'number')) {
        return parseInt(item.extra.biz_ext.rating);
      } else {
        return 0;
      }
    }
  }
});

/***/ }),
/* 7 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
  widgetName: 'gaodeList',
  widgetType: 'list',
  fullscreen: true,

  data: function data() {
    return {
      currentMenu: '',
      currentDistance: {
        value: '500米',
        text: '500米'
      },
      currentType: {
        text: '全部美食'
      },
      currentSubType: {},
      currentOrderType: {
        value: '推荐排序',
        text: '推荐排序'
      },
      distanceList: [{
        value: '500米',
        text: '500米'
      }, {
        value: '1000米',
        text: '1000米'
      }, {
        value: '2000米',
        text: '2000米'
      }, {
        value: '5000米',
        text: '5000米'
      }, {
        value: '全城',
        text: '全城'
      }],
      orderTypeList: [{
        value: '推荐排序',
        text: '推荐排序'
      }, {
        value: '距离优先',
        text: '距离优先'
      }, {
        value: '好评优先',
        text: '好评优先'
      }, {
        value: '低价优先',
        text: '低价优先'
      }, {
        value: '高价优先',
        text: '高价优先'
      }],
      typeList: [{
        text: '全部美食',
        subTypes: [{
          value: '全部',
          text: '全部'
        }]
      }, {
        text: '中餐厅',
        subTypes: [{
          value: '全部',
          text: '全部'
        }, {
          value: '火锅',
          text: '火锅'
        }, {
          value: '川菜',
          text: '川菜'
        }, {
          value: '自助餐',
          text: '自助餐'
        }, {
          value: '湘菜',
          text: '湘菜'
        }, {
          value: '粤菜',
          text: '粤菜'
        }, {
          value: '上海菜',
          text: '上海菜'
        }, {
          value: '鲁菜',
          text: '鲁菜'
        }, {
          value: '东北菜',
          text: '东北菜'
        }]
      }, {
        text: '西餐厅',
        subTypes: [{
          value: '全部',
          text: '全部'
        }]
      }, {
        text: '日本料理',
        subTypes: [{
          value: '全部',
          text: '全部'
        }]
      }, {
        text: '韩国料理',
        subTypes: [{
          value: '全部',
          text: '全部'
        }]
      }, {
        text: '东南亚餐厅',
        subTypes: [{
          value: '全部',
          text: '全部'
        }]
      }, {
        text: '快餐',
        subTypes: [{
          value: '全部',
          text: '全部'
        }]
      }, {
        text: '咖啡厅',
        subTypes: [{
          value: '全部',
          text: '全部'
        }]
      }, {
        text: '茶艺馆',
        subTypes: [{
          value: '全部',
          text: '全部'
        }]
      }]
    };
  },


  props: {
    message: Object
  },

  methods: {
    handleClick: function handleClick(index) {
      if (!window.Dui) return;
      window.Dui.send({
        'event': 'list.item.select',
        'data': {
          'index': index
        }
      });
    },
    clickMenu: function clickMenu(key) {
      this.currentMenu = this.currentMenu === key ? '' : key;
    },
    selectDistance: function selectDistance(distance) {
      this.currentMenu = '';
      this.currentDistance = distance;

      if (!window.Dui) return;
      window.Dui.send({
        'event': 'recommendation.item.select',
        'data': {
          'text': distance.text
        }
      });
    },
    selectType: function selectType(type) {
      this.currentType = type;
    },
    selectSubType: function selectSubType(type, subType) {
      this.currentMenu = '';
      this.currentType = type;
      this.currentSubType = subType;

      if (!window.Dui) return;
      window.Dui.send({
        'event': 'recommendation.item.select',
        'data': {
          'text': subType.text
        }
      });
    },
    selectOrderType: function selectOrderType(orderType) {
      this.currentMenu = '';
      this.currentOrderType = orderType;

      if (!window.Dui) return;
      window.Dui.send({
        'event': 'recommendation.item.select',
        'data': {
          'text': orderType.text
        }
      });
    }
  }
});

/***/ }),
/* 8 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
//
//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'helloWorld',
  widgetType: 'text',
  testData: {
    data: {
      text: '测试数据供预览(文字内容)'
    }
  },

  props: {
    message: Object
  }
});

/***/ }),
/* 9 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__src_hello_world__ = __webpack_require__(4);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__src_hello_world___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__src_hello_world__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__src_custom_card__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__src_custom_card___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__src_custom_card__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__src_gaodeList__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__src_gaodeList___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2__src_gaodeList__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__src_gaodeFoodList__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__src_gaodeFoodList___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3__src_gaodeFoodList__);





// 导出 install 函数
// Vue.use() 会调用这个函数
var install = function install(Vue) {
  var opts = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

  // 如果安装过就忽略
  if (install.installed) return;

  // 指定组件 name
  Vue.component(__WEBPACK_IMPORTED_MODULE_0__src_hello_world___default.a.name, __WEBPACK_IMPORTED_MODULE_0__src_hello_world___default.a);
  Vue.component(__WEBPACK_IMPORTED_MODULE_1__src_custom_card___default.a.name, __WEBPACK_IMPORTED_MODULE_1__src_custom_card___default.a);
  Vue.component(__WEBPACK_IMPORTED_MODULE_2__src_gaodeList___default.a.widgetName, __WEBPACK_IMPORTED_MODULE_2__src_gaodeList___default.a);
  Vue.component('gaodeFoodList', __WEBPACK_IMPORTED_MODULE_3__src_gaodeFoodList___default.a);
};

// 自动安装 方便打包成压缩文件, 用<script scr=''></script>的方式引用
if (typeof window !== 'undefined' && window.Vue) {
  install(window.Vue);
}

// 把模块导出
/* harmony default export */ __webpack_exports__["default"] = ({
  install: install,
  // helloWorld: HelloWorld,
  // customContentCard: CustomCard
  gaodeList: __WEBPACK_IMPORTED_MODULE_2__src_gaodeList___default.a,
  gaodeFoodList: __WEBPACK_IMPORTED_MODULE_3__src_gaodeFoodList___default.a
});

/***/ }),
/* 10 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 11 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 12 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 13 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 14 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 15 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', [_c('div', {
    staticClass: "gaode-list"
  }, [_c('div', {
    staticClass: "gaode-list-header"
  }, [_c('div', [_c('div', {
    class: {
      'header-item': true, 'active': _vm.currentMenu === 'distance'
    },
    on: {
      "click": function($event) {
        _vm.clickMenu('distance')
      }
    }
  }, [_vm._v("\n          " + _vm._s(_vm.currentDistance && _vm.currentDistance.text) + "\n          "), _c('i', {
    staticClass: "gaode gaode-down"
  })]), _vm._v(" "), _c('div', {
    class: {
      'header-item': true, 'active': _vm.currentMenu === 'type'
    },
    on: {
      "click": function($event) {
        _vm.clickMenu('type')
      }
    }
  }, [_vm._v("\n          " + _vm._s((_vm.currentSubType && _vm.currentSubType.text) || (_vm.currentType && _vm.currentType.text)) + "\n          "), _c('i', {
    staticClass: "gaode gaode-down"
  })]), _vm._v(" "), _c('div', {
    class: {
      'header-item': true, 'active': _vm.currentMenu === 'orderType'
    },
    on: {
      "click": function($event) {
        _vm.clickMenu('orderType')
      }
    }
  }, [_vm._v("\n          " + _vm._s(_vm.currentOrderType.text) + "\n          "), _c('i', {
    staticClass: "gaode gaode-down"
  })])])]), _vm._v(" "), (_vm.currentMenu === 'distance') ? _c('div', {
    staticClass: "menu"
  }, [_c('div', {
    staticClass: "menu-item-container"
  }, _vm._l((_vm.distanceList), function(distance) {
    return _c('div', {
      class: {
        'menu-item': true, 'active': _vm.currentDistance.text === distance.text
      },
      on: {
        "click": function($event) {
          _vm.selectDistance(distance)
        }
      }
    }, [_vm._v("\n          " + _vm._s(distance.text) + "\n        ")])
  }))]) : _vm._e(), _vm._v(" "), (_vm.currentMenu === 'type') ? _c('div', {
    staticClass: "menu type"
  }, [_c('div', {
    staticClass: "menu-item-container"
  }, [_vm._l((_vm.typeList), function(type) {
    return _c('div', {
      class: {
        'menu-item': true, 'active': _vm.currentType.text === type.text
      },
      on: {
        "click": function($event) {
          _vm.selectType(type)
        }
      }
    }, [_vm._v("\n          " + _vm._s(type.text) + "\n          "), (type.subTypes) ? _c('i', {
      class: {
        'gaode': true, 'gaode-down': true, 'right-icon': true, 'middle': _vm.currentType.subTypes && _vm.currentType.subTypes[0]
      }
    }) : _vm._e()])
  }), _vm._v(" "), (_vm.currentType.subTypes && _vm.currentType.subTypes[0]) ? _c('div', {
    staticClass: "subtype"
  }, _vm._l((_vm.currentType.subTypes), function(subtype) {
    return _c('div', {
      class: {
        'menu-sub-item': true, 'active': _vm.currentSubType.text === subtype.text
      },
      on: {
        "click": function($event) {
          _vm.selectSubType(_vm.currentType, subtype)
        }
      }
    }, [_vm._v("\n            " + _vm._s(subtype.text) + "\n          ")])
  })) : _vm._e()], 2)]) : _vm._e(), _vm._v(" "), (_vm.currentMenu === 'orderType') ? _c('div', {
    staticClass: "menu"
  }, [_c('div', {
    staticClass: "menu-item-container"
  }, _vm._l((_vm.orderTypeList), function(orderType) {
    return _c('div', {
      class: {
        'menu-item': true, 'active': _vm.currentOrderType.text === orderType.text
      },
      on: {
        "click": function($event) {
          _vm.selectOrderType(orderType)
        }
      }
    }, [_vm._v("\n          " + _vm._s(orderType.text) + "\n        ")])
  }))]) : _vm._e(), _vm._v(" "), _c('div', {
    staticClass: "gaode-list-body"
  }, [_c('div', _vm._l((_vm.message.data.content), function(item, index) {
    return _c('div', {
      staticClass: "body-item",
      on: {
        "click": function($event) {
          _vm.handleClick(index)
        }
      }
    }, [(item.imageUrl) ? _c('img', {
      staticClass: "body-item-img",
      attrs: {
        "src": item.imageUrl
      }
    }) : _vm._e(), _vm._v(" "), (item.title) ? _c('div', {
      staticClass: "body-item-title"
    }, [_vm._v(_vm._s(item.title))]) : _vm._e(), _vm._v(" "), _c('div', {
      staticClass: "body-item-label"
    }, [_c('span', _vm._l((5), function(n) {
      return _c('i', {
        class: {
          'gaode': true, 'gaode-star1': true, 'active': n <= _vm.getRate(item)
        }
      })
    })), _vm._v(" "), (item.extra && item.extra.biz_ext && item.extra.biz_ext.cost && (typeof item.extra.biz_ext.cost === 'string' || typeof item.extra.biz_ext.cost === 'number')) ? _c('span', [_vm._v("\n              人均消费： "), _c('span', {
      staticClass: "orange"
    }, [_vm._v("￥" + _vm._s(item.extra.biz_ext.cost))])]) : _vm._e()]), _vm._v(" "), _c('div', {
      staticClass: "body-item-subtitle"
    }, [(item.extra && item.extra.type) ? _c('span', [_vm._v(_vm._s(item.extra.type.replace(/^.+;/, '')))]) : _vm._e(), _vm._v(" "), (item.extra && item.extra.distance) ? _c('span', [_vm._v(_vm._s(item.extra.distance) + " 米")]) : _vm._e()])])
  })), _vm._v(" "), (_vm.currentMenu) ? _c('div', {
    staticClass: "cover",
    on: {
      "click": function($event) {
        _vm.currentMenu = ''
      }
    }
  }) : _vm._e()])])])
},staticRenderFns: []}

/***/ }),
/* 16 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', [_c('div', {
    staticClass: "content-hello-world zoomIn"
  }, [_c('p', [_vm._v(_vm._s(_vm.message.data.title))]), _vm._v(" "), _c('p', {
    staticClass: "small-text"
  }, [_vm._v(_vm._s(_vm.message.data.subTitle))])])])
},staticRenderFns: []}

/***/ }),
/* 17 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', [_c('div', {
    staticClass: "text-hello-world zoomIn"
  }, [_c('h3', [_vm._v("hello World2!")]), _vm._v(" "), _c('p', [_vm._v(_vm._s(_vm.message.data.text))])])])
},staticRenderFns: []}

/***/ }),
/* 18 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', [_c('div', {
    staticClass: "gaode-list"
  }, [(false) ? _c('div', {
    staticClass: "gaode-list-header"
  }, [_c('div', [_c('div', {
    class: {
      'header-item': true, 'active': _vm.currentMenu === 'distance'
    },
    on: {
      "click": function($event) {
        _vm.clickMenu('distance')
      }
    }
  }, [_vm._v(_vm._s(_vm.currentDistance && _vm.currentDistance.text))]), _vm._v(" "), _c('div', {
    class: {
      'header-item': true, 'active': _vm.currentMenu === 'type'
    },
    on: {
      "click": function($event) {
        _vm.clickMenu('type')
      }
    }
  }, [_vm._v(_vm._s((_vm.currentSubType && _vm.currentSubType.text) || (_vm.currentType && _vm.currentType.text)))]), _vm._v(" "), _c('div', {
    class: {
      'header-item': true, 'active': _vm.currentMenu === 'orderType'
    },
    on: {
      "click": function($event) {
        _vm.clickMenu('orderType')
      }
    }
  }, [_vm._v(_vm._s(_vm.currentOrderType.text))])]), _vm._v(" "), (_vm.currentMenu === 'distance') ? _c('div', {
    staticClass: "menu"
  }, _vm._l((_vm.distanceList), function(distance) {
    return _c('div', {
      class: {
        'menu-item': true, 'active': _vm.currentDistance.text === distance.text
      },
      on: {
        "click": function($event) {
          _vm.selectDistance(distance)
        }
      }
    }, [_vm._v("\n          " + _vm._s(distance.text) + "\n        ")])
  })) : _vm._e(), _vm._v(" "), (_vm.currentMenu === 'type') ? _c('div', {
    staticClass: "menu type"
  }, [_vm._l((_vm.typeList), function(type) {
    return _c('div', {
      class: {
        'menu-item': true, 'active': _vm.currentType.text === type.text
      },
      on: {
        "click": function($event) {
          _vm.selectType(type)
        }
      }
    }, [_vm._v("\n          " + _vm._s(type.text) + "\n        ")])
  }), _vm._v(" "), (_vm.currentType.subTypes && _vm.currentType.subTypes[0]) ? _c('div', {
    staticClass: "subtype"
  }, _vm._l((_vm.currentType.subTypes), function(subtype) {
    return _c('div', {
      class: {
        'menu-sub-item': true, 'active': _vm.currentSubType.text === subtype.text
      },
      on: {
        "click": function($event) {
          _vm.selectSubType(_vm.currentType, subtype)
        }
      }
    }, [_vm._v("\n            " + _vm._s(subtype.text) + "\n          ")])
  })) : _vm._e()], 2) : _vm._e(), _vm._v(" "), (_vm.currentMenu === 'orderType') ? _c('div', {
    staticClass: "menu"
  }, _vm._l((_vm.orderTypeList), function(orderType) {
    return _c('div', {
      class: {
        'menu-item': true, 'active': _vm.currentOrderType.text === orderType.text
      },
      on: {
        "click": function($event) {
          _vm.selectOrderType(orderType)
        }
      }
    }, [_vm._v("\n          " + _vm._s(orderType.text) + "\n        ")])
  })) : _vm._e()]) : _vm._e(), _vm._v(" "), _c('div', {
    staticClass: "gaode-list-body"
  }, [_c('div', _vm._l((_vm.message.data.content), function(item, index) {
    return _c('div', {
      staticClass: "body-item",
      on: {
        "click": function($event) {
          _vm.handleClick(index)
        }
      }
    }, [(item.imageUrl) ? _c('img', {
      staticClass: "body-item-img",
      attrs: {
        "src": item.imageUrl
      }
    }) : _vm._e(), _vm._v(" "), (item.title) ? _c('div', {
      staticClass: "body-item-title"
    }, [_vm._v(_vm._s(item.title))]) : _vm._e(), _vm._v(" "), (item.label) ? _c('div', {
      staticClass: "body-item-label"
    }, [_vm._v(_vm._s(item.label))]) : _vm._e(), _vm._v(" "), (item.subTitle) ? _c('div', {
      staticClass: "body-item-subtitle"
    }, [_vm._v(_vm._s(item.subTitle))]) : _vm._e()])
  })), _vm._v(" "), (_vm.currentMenu) ? _c('div', {
    staticClass: "cover",
    on: {
      "click": function($event) {
        _vm.currentMenu = ''
      }
    }
  }) : _vm._e()])])])
},staticRenderFns: []}

/***/ })
/******/ ]);
});
//# sourceMappingURL=main.js.map